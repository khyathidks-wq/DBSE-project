import { createContext, useCallback, useContext, useMemo, useState } from "react";
import {
  initialCrops,
  initialAssessments,
  initialHistory,
  alerts as mockAlerts,
} from "../data/mockData";

const DataContext = createContext(null);

let idCounter = 100;
const nextId = (prefix) => `${prefix}${idCounter++}`;

export function DataProvider({ children }) {
  const [crops, setCrops] = useState(initialCrops);
  const [assessments, setAssessments] = useState(initialAssessments);
  const [history, setHistory] = useState(initialHistory);
  const [alerts] = useState(mockAlerts);
  const [toasts, setToasts] = useState([]);

  const pushToast = useCallback((message, variant = "success") => {
    const id = nextId("t");
    setToasts((prev) => [...prev, { id, message, variant }]);
    setTimeout(() => {
      setToasts((prev) => prev.filter((t) => t.id !== id));
    }, 3200);
  }, []);

  const addCrop = useCallback(
    (crop) => {
      const newCrop = {
        id: nextId("c"),
        healthScore: crop.status === "Healthy" ? 82 : crop.status === "Critical" ? 38 : 60,
        lastChecked: new Date().toISOString().slice(0, 10),
        image:
          "https://images.unsplash.com/photo-1500595046743-cd271d694d30?auto=format&fit=crop&w=400&q=60",
        ...crop,
      };
      setCrops((prev) => [newCrop, ...prev]);
      pushToast(`${newCrop.name} was added successfully.`);
      return newCrop;
    },
    [pushToast]
  );

  const updateCrop = useCallback(
    (id, patch) => {
      setCrops((prev) => prev.map((c) => (c.id === id ? { ...c, ...patch } : c)));
    },
    []
  );

  const deleteCrop = useCallback(
    (id) => {
      setCrops((prev) => prev.filter((c) => c.id !== id));
      pushToast("Crop record deleted.", "danger");
    },
    [pushToast]
  );

  const addAssessment = useCallback(
    (assessment) => {
      const newAssessment = { id: nextId("a"), date: new Date().toISOString().slice(0, 10), ...assessment };
      setAssessments((prev) => [newAssessment, ...prev]);
      setHistory((prev) => [
        {
          id: nextId("h"),
          date: newAssessment.date,
          cropId: newAssessment.cropId,
          cropName: newAssessment.cropName,
          healthScore: newAssessment.healthScore,
          condition: newAssessment.status,
          issue: newAssessment.possibleIssue,
          action:
            newAssessment.status === "Healthy" ? "Continue Monitoring" : "Review & Monitor",
        },
        ...prev,
      ]);
      if (newAssessment.cropId) {
        updateCrop(newAssessment.cropId, {
          healthScore: newAssessment.healthScore,
          status: newAssessment.status,
          lastChecked: newAssessment.date,
        });
      }
      return newAssessment;
    },
    [updateCrop]
  );

  const getCropById = useCallback((id) => crops.find((c) => c.id === id), [crops]);

  const getAssessmentsForCrop = useCallback(
    (cropId) => assessments.filter((a) => a.cropId === cropId),
    [assessments]
  );

  const value = useMemo(
    () => ({
      crops,
      assessments,
      history,
      alerts,
      toasts,
      pushToast,
      addCrop,
      updateCrop,
      deleteCrop,
      addAssessment,
      getCropById,
      getAssessmentsForCrop,
    }),
    [crops, assessments, history, alerts, toasts, pushToast, addCrop, updateCrop, deleteCrop, addAssessment, getCropById, getAssessmentsForCrop]
  );

  return <DataContext.Provider value={value}>{children}</DataContext.Provider>;
}

export function useData() {
  const ctx = useContext(DataContext);
  if (!ctx) throw new Error("useData must be used within DataProvider");
  return ctx;
}
