import { createContext, useContext, useEffect, useState } from "react";

const AuthContext = createContext(null);

const STORAGE_KEY = "agrisense_user";

export function AuthProvider({ children }) {
  const [user, setUser] = useState(null);
  const [ready, setReady] = useState(false);

  useEffect(() => {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (raw) {
      try {
        setUser(JSON.parse(raw));
      } catch {
        localStorage.removeItem(STORAGE_KEY);
      }
    }
    setReady(true);
  }, []);

  const login = ({ email }) => {
    // Mock authentication — any credentials succeed. A real backend call
    // (POST /auth/login) would replace this and return a token + profile.
    const mockUser = {
      id: "u1",
      fullName: email.split("@")[0].replace(/[._]/g, " ") || "Farmer",
      email,
      phone: "+91 98765 43210",
      location: "Nalgonda, Telangana",
      preferredCrop: "Tomato",
    };
    localStorage.setItem(STORAGE_KEY, JSON.stringify(mockUser));
    localStorage.setItem("agrisense_token", "demo-token");
    setUser(mockUser);
    return mockUser;
  };

  const register = (form) => {
    const mockUser = {
      id: "u1",
      fullName: form.fullName,
      email: form.email,
      phone: form.phone,
      location: form.location,
      preferredCrop: form.preferredCrop,
    };
    localStorage.setItem(STORAGE_KEY, JSON.stringify(mockUser));
    localStorage.setItem("agrisense_token", "demo-token");
    setUser(mockUser);
    return mockUser;
  };

  const updateProfile = (patch) => {
    setUser((prev) => {
      const next = { ...prev, ...patch };
      localStorage.setItem(STORAGE_KEY, JSON.stringify(next));
      return next;
    });
  };

  const logout = () => {
    localStorage.removeItem(STORAGE_KEY);
    localStorage.removeItem("agrisense_token");
    setUser(null);
  };

  return (
    <AuthContext.Provider value={{ user, ready, login, register, logout, updateProfile }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error("useAuth must be used within AuthProvider");
  return ctx;
}
