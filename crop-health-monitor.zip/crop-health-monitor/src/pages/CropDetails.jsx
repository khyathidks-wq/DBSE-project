import { Link, useNavigate, useParams } from "react-router-dom";
import { useData } from "../context/DataContext";
import StatusPill from "../components/StatusPill";

function scoreColor(score) {
  if (score >= 70) return "var(--green-600)";
  if (score >= 45) return "var(--amber-600)";
  return "var(--red-600)";
}

export default function CropDetails() {
  const { id } = useParams();
  const navigate = useNavigate();
  const { getCropById, getAssessmentsForCrop, history } = useData();
  const crop = getCropById(id);

  if (!crop) {
    return (
      <div className="empty-state">
        <i className="bi bi-search mb-2" style={{ fontSize: "1.8rem" }} />
        <p>We couldn't find that crop.</p>
        <Link to="/crops" className="btn btn-agri-primary btn-sm">
          Back to Crop Management
        </Link>
      </div>
    );
  }

  const cropAssessments = getAssessmentsForCrop(id);
  const latest = cropAssessments[0];
  const cropHistory = history.filter((h) => h.cropId === id);
  const color = scoreColor(crop.healthScore);
  const circumference = 2 * Math.PI * 60;
  const dash = (crop.healthScore / 100) * circumference;

  return (
    <div>
      <div className="d-flex align-items-center gap-2 mb-3">
        <button className="btn btn-agri-ghost btn-sm" onClick={() => navigate(-1)}>
          <i className="bi bi-arrow-left" />
        </button>
        <span className="text-faint" style={{ fontSize: "0.85rem" }}>
          Crops / {crop.name}
        </span>
      </div>

      <div className="row g-3 mb-3">
        <div className="col-lg-8">
          <div className="surface-card p-4 h-100">
            <div className="d-flex flex-wrap justify-content-between gap-3 align-items-start">
              <div className="d-flex gap-3">
                <img
                  src={crop.image}
                  alt={crop.name}
                  style={{ width: 88, height: 88, borderRadius: 14, objectFit: "cover" }}
                />
                <div>
                  <h1 className="mb-1">{crop.name}</h1>
                  <p className="mb-2">
                    {crop.type} · {crop.location}
                  </p>
                  <StatusPill status={crop.status} />
                </div>
              </div>
              <Link to={`/crops/${crop.id}/edit`} className="btn btn-agri-outline btn-sm">
                <i className="bi bi-pencil me-1" /> Edit
              </Link>
            </div>

            <hr className="divider" />

            <div className="row g-3">
              <div className="col-6 col-md-3">
                <div className="text-faint" style={{ fontSize: "0.78rem" }}>
                  Planting Date
                </div>
                <div className="fw-semibold">{crop.plantingDate}</div>
              </div>
              <div className="col-6 col-md-3">
                <div className="text-faint" style={{ fontSize: "0.78rem" }}>
                  Growth Stage
                </div>
                <div className="fw-semibold">{crop.growthStage}</div>
              </div>
              <div className="col-6 col-md-3">
                <div className="text-faint" style={{ fontSize: "0.78rem" }}>
                  Area
                </div>
                <div className="fw-semibold">{crop.area}</div>
              </div>
              <div className="col-6 col-md-3">
                <div className="text-faint" style={{ fontSize: "0.78rem" }}>
                  Last Checked
                </div>
                <div className="fw-semibold">{crop.lastChecked}</div>
              </div>
            </div>
            {crop.notes && (
              <>
                <hr className="divider" />
                <div className="text-faint mb-1" style={{ fontSize: "0.78rem" }}>
                  Notes
                </div>
                <p className="mb-0">{crop.notes}</p>
              </>
            )}
          </div>
        </div>

        <div className="col-lg-4">
          <div className="surface-card p-4 h-100 d-flex flex-column align-items-center justify-content-center text-center">
            <div className="text-faint mb-2" style={{ fontSize: "0.8rem", fontWeight: 600 }}>
              HEALTH SCORE
            </div>
            <div className="score-ring-wrap">
              <svg viewBox="0 0 140 140" width="148" height="148">
                <circle cx="70" cy="70" r="60" fill="none" stroke="var(--border-soft)" strokeWidth="12" />
                <circle
                  cx="70"
                  cy="70"
                  r="60"
                  fill="none"
                  stroke={color}
                  strokeWidth="12"
                  strokeLinecap="round"
                  strokeDasharray={`${dash} ${circumference}`}
                  transform="rotate(-90 70 70)"
                />
              </svg>
              <div className="score-ring-value">
                <span className="n">{crop.healthScore}</span>
                <span className="d">/ 100</span>
              </div>
            </div>
            <p className="mt-3 mb-3">{crop.status}</p>
            <Link to="/upload-image" state={{ cropId: crop.id, cropName: crop.name }} className="btn btn-agri-primary w-100">
              <i className="bi bi-clipboard2-pulse me-2" />
              Run Health Assessment
            </Link>
          </div>
        </div>
      </div>

      <div className="row g-3">
        <div className="col-lg-6">
          <div className="surface-card p-4 h-100">
            <div className="section-heading">
              <h3>Latest Assessment</h3>
            </div>
            {latest ? (
              <div>
                <div className="d-flex gap-3 mb-3">
                  <img
                    src={latest.image}
                    alt=""
                    style={{ width: 64, height: 64, borderRadius: 10, objectFit: "cover" }}
                  />
                  <div>
                    <StatusPill status={latest.status} />
                    <div className="fw-semibold mt-1">{latest.possibleIssue}</div>
                    <div className="text-faint" style={{ fontSize: "0.8rem" }}>
                      {latest.date} · {latest.confidence}% confidence (estimated)
                    </div>
                  </div>
                </div>
                <p className="mb-0">{latest.explanation}</p>
              </div>
            ) : (
              <div className="empty-state">
                <p className="mb-2">No assessments yet for this crop.</p>
                <Link to="/upload-image" className="btn btn-agri-primary btn-sm">
                  Upload an image to assess
                </Link>
              </div>
            )}
          </div>
        </div>

        <div className="col-lg-6">
          <div className="surface-card p-4 h-100">
            <div className="section-heading">
              <h3>Monitoring Timeline</h3>
            </div>
            {cropHistory.length ? (
              <div className="timeline">
                {cropHistory.map((h) => (
                  <div className="timeline-item" key={h.id}>
                    <span
                      className={
                        "timeline-dot " +
                        (h.condition === "Critical" ? "critical" : h.condition === "Needs Attention" ? "attention" : "")
                      }
                    />
                    <div className="d-flex justify-content-between">
                      <span className="fw-semibold" style={{ fontSize: "0.88rem" }}>
                        {h.issue === "None" ? "Routine check" : h.issue}
                      </span>
                      <span className="text-faint" style={{ fontSize: "0.78rem" }}>
                        {h.date}
                      </span>
                    </div>
                    <div className="text-faint" style={{ fontSize: "0.82rem" }}>
                      Score {h.healthScore} · {h.action}
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="empty-state">
                <p className="mb-0">No monitoring history recorded yet.</p>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
