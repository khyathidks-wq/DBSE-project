import { useState } from "react";
import { useAuth } from "../context/AuthContext";
import { useData } from "../context/DataContext";
import { cropTypes } from "../data/mockData";

export default function Profile() {
  const { user, updateProfile } = useAuth();
  const { pushToast } = useData();
  const [form, setForm] = useState(user);
  const [notifs, setNotifs] = useState({ email: true, sms: false, critical: true });

  const handleChange = (e) => setForm({ ...form, [e.target.name]: e.target.value });

  const handleSave = (e) => {
    e.preventDefault();
    updateProfile(form);
    pushToast("Profile updated successfully.");
  };

  const initials = (user?.fullName || "F")
    .split(" ")
    .map((p) => p[0])
    .slice(0, 2)
    .join("")
    .toUpperCase();

  return (
    <div>
      <div className="mb-4">
        <h1>Profile &amp; Settings</h1>
        <p className="mb-0">Manage your account details and notification preferences.</p>
      </div>

      <div className="row g-3">
        <div className="col-lg-4">
          <div className="surface-card p-4 text-center">
            <div
              className="avatar-circle mx-auto mb-3"
              style={{ width: 76, height: 76, fontSize: "1.5rem", background: "var(--mint-200)" }}
            >
              {initials}
            </div>
            <h4 className="mb-1">{user?.fullName}</h4>
            <p className="mb-3 text-faint" style={{ fontSize: "0.85rem" }}>
              {user?.email}
            </p>
            <div className="d-flex justify-content-center gap-2 flex-wrap">
              <span className="chip">
                <i className="bi bi-geo-alt" /> {user?.location}
              </span>
              <span className="chip">
                <i className="bi bi-flower1" /> {user?.preferredCrop}
              </span>
            </div>
          </div>
        </div>

        <div className="col-lg-8">
          <form className="surface-card p-4 mb-3" onSubmit={handleSave}>
            <h4 className="mb-3">Profile information</h4>
            <div className="row g-3">
              <div className="col-md-6">
                <label className="form-label">Full name</label>
                <input name="fullName" className="form-control" value={form.fullName} onChange={handleChange} />
              </div>
              <div className="col-md-6">
                <label className="form-label">Email</label>
                <input name="email" type="email" className="form-control" value={form.email} onChange={handleChange} />
              </div>
              <div className="col-md-6">
                <label className="form-label">Phone</label>
                <input name="phone" className="form-control" value={form.phone} onChange={handleChange} />
              </div>
              <div className="col-md-6">
                <label className="form-label">Location</label>
                <input name="location" className="form-control" value={form.location} onChange={handleChange} />
              </div>
              <div className="col-md-6">
                <label className="form-label">Preferred crop</label>
                <select name="preferredCrop" className="form-select" value={form.preferredCrop} onChange={handleChange}>
                  {cropTypes.map((c) => (
                    <option key={c}>{c}</option>
                  ))}
                </select>
              </div>
            </div>
            <div className="d-flex justify-content-end mt-3">
              <button type="submit" className="btn btn-agri-primary">
                <i className="bi bi-check2 me-2" />
                Save Changes
              </button>
            </div>
          </form>

          <div className="surface-card p-4">
            <h4 className="mb-3">Notification preferences</h4>
            {[
              { key: "email", label: "Email alerts", desc: "Receive a summary of crop alerts by email." },
              { key: "sms", label: "SMS alerts", desc: "Get a text message for urgent issues." },
              { key: "critical", label: "Critical-only mode", desc: "Only notify me about critical health issues." },
            ].map((n) => (
              <div key={n.key} className="d-flex justify-content-between align-items-center py-2 border-bottom" style={{ borderColor: "var(--border-soft)" }}>
                <div>
                  <div className="fw-semibold" style={{ fontSize: "0.92rem" }}>
                    {n.label}
                  </div>
                  <div className="text-faint" style={{ fontSize: "0.8rem" }}>
                    {n.desc}
                  </div>
                </div>
                <div className="form-check form-switch">
                  <input
                    className="form-check-input"
                    type="checkbox"
                    checked={notifs[n.key]}
                    onChange={() => setNotifs((prev) => ({ ...prev, [n.key]: !prev[n.key] }))}
                    style={{ width: "2.4em", height: "1.3em" }}
                  />
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
