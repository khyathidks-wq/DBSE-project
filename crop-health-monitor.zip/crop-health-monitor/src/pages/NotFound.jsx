import { Link } from "react-router-dom";

export default function NotFound() {
  return (
    <div
      className="d-flex flex-column align-items-center justify-content-center text-center"
      style={{ minHeight: "100vh", padding: "2rem", background: "var(--paper)" }}
    >
      <div
        className="stat-icon-badge mb-3"
        style={{ width: 64, height: 64, fontSize: "1.8rem", "--accent": "var(--amber-600)", "--accent-bg": "var(--amber-100)" }}
      >
        <i className="bi bi-signpost-split" />
      </div>
      <h1 className="mb-2">This field doesn't exist</h1>
      <p className="mb-4" style={{ maxWidth: 380 }}>
        The page you're looking for isn't part of AgriSense. Let's get you back to monitoring your crops.
      </p>
      <Link to="/dashboard" className="btn btn-agri-primary">
        <i className="bi bi-arrow-left me-2" />
        Back to Dashboard
      </Link>
    </div>
  );
}
