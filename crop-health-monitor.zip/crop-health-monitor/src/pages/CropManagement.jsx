import { useMemo, useState } from "react";
import { Link } from "react-router-dom";
import { useData } from "../context/DataContext";
import { cropTypes } from "../data/mockData";
import StatusPill from "../components/StatusPill";

const PAGE_SIZE = 5;

export default function CropManagement() {
  const { crops, deleteCrop } = useData();
  const [search, setSearch] = useState("");
  const [typeFilter, setTypeFilter] = useState("All");
  const [statusFilter, setStatusFilter] = useState("All");
  const [sortBy, setSortBy] = useState("name-asc");
  const [page, setPage] = useState(1);
  const [confirmId, setConfirmId] = useState(null);

  const filtered = useMemo(() => {
    let list = crops.filter((c) => {
      const matchSearch =
        !search ||
        c.name.toLowerCase().includes(search.toLowerCase()) ||
        c.location.toLowerCase().includes(search.toLowerCase());
      const matchType = typeFilter === "All" || c.type === typeFilter;
      const matchStatus = statusFilter === "All" || c.status === statusFilter;
      return matchSearch && matchType && matchStatus;
    });

    list = [...list].sort((a, b) => {
      switch (sortBy) {
        case "name-asc":
          return a.name.localeCompare(b.name);
        case "name-desc":
          return b.name.localeCompare(a.name);
        case "score-asc":
          return a.healthScore - b.healthScore;
        case "score-desc":
          return b.healthScore - a.healthScore;
        case "recent":
          return new Date(b.lastChecked) - new Date(a.lastChecked);
        default:
          return 0;
      }
    });
    return list;
  }, [crops, search, typeFilter, statusFilter, sortBy]);

  const totalPages = Math.max(1, Math.ceil(filtered.length / PAGE_SIZE));
  const pageItems = filtered.slice((page - 1) * PAGE_SIZE, page * PAGE_SIZE);

  const resetPage = () => setPage(1);

  return (
    <div>
      <div className="section-heading">
        <div>
          <h1>Crop Management</h1>
          <p className="mb-0">View, filter, and manage every crop on record.</p>
        </div>
        <Link to="/crops/add" className="btn btn-agri-primary">
          <i className="bi bi-plus-lg me-2" />
          Add Crop
        </Link>
      </div>

      <div className="surface-card p-3 mb-3">
        <div className="row g-2 align-items-center">
          <div className="col-md-4">
            <div className="input-affix">
              <input
                className="form-control"
                placeholder="Search by crop name or location..."
                value={search}
                onChange={(e) => {
                  setSearch(e.target.value);
                  resetPage();
                }}
              />
              <i className="bi bi-search affix-btn" style={{ pointerEvents: "none" }} />
            </div>
          </div>
          <div className="col-6 col-md-2">
            <select
              className="form-select"
              value={typeFilter}
              onChange={(e) => {
                setTypeFilter(e.target.value);
                resetPage();
              }}
            >
              <option>All</option>
              {cropTypes.map((t) => (
                <option key={t}>{t}</option>
              ))}
            </select>
          </div>
          <div className="col-6 col-md-2">
            <select
              className="form-select"
              value={statusFilter}
              onChange={(e) => {
                setStatusFilter(e.target.value);
                resetPage();
              }}
            >
              <option>All</option>
              <option>Healthy</option>
              <option>Needs Attention</option>
              <option>Critical</option>
            </select>
          </div>
          <div className="col-6 col-md-2 ms-md-auto">
            <select className="form-select" value={sortBy} onChange={(e) => setSortBy(e.target.value)}>
              <option value="name-asc">Name (A–Z)</option>
              <option value="name-desc">Name (Z–A)</option>
              <option value="score-desc">Health Score (High–Low)</option>
              <option value="score-asc">Health Score (Low–High)</option>
              <option value="recent">Recently checked</option>
            </select>
          </div>
        </div>
      </div>

      <div className="surface-card p-0">
        <div className="table-responsive">
          <table className="agri-table">
            <thead>
              <tr>
                <th>Crop</th>
                <th>Location</th>
                <th>Stage</th>
                <th>Health Score</th>
                <th>Status</th>
                <th>Last Monitored</th>
                <th style={{ textAlign: "right" }}>Actions</th>
              </tr>
            </thead>
            <tbody>
              {pageItems.map((c) => (
                <tr key={c.id}>
                  <td>
                    <div className="d-flex align-items-center gap-2">
                      <img src={c.image} alt="" className="crop-thumb" />
                      <div>
                        <div className="fw-semibold text-forest">{c.name}</div>
                        <div className="text-faint" style={{ fontSize: "0.78rem" }}>
                          {c.type} · {c.area}
                        </div>
                      </div>
                    </div>
                  </td>
                  <td>{c.location}</td>
                  <td>{c.growthStage}</td>
                  <td className="fw-semibold">{c.healthScore}/100</td>
                  <td>
                    <StatusPill status={c.status} />
                  </td>
                  <td className="text-faint">{c.lastChecked}</td>
                  <td>
                    <div className="d-flex gap-1 justify-content-end">
                      <Link to={`/crops/${c.id}`} className="btn btn-agri-ghost btn-sm" title="View details">
                        <i className="bi bi-eye" />
                      </Link>
                      <Link to={`/crops/${c.id}/edit`} className="btn btn-agri-ghost btn-sm" title="Edit">
                        <i className="bi bi-pencil" />
                      </Link>
                      <button
                        className="btn btn-agri-ghost btn-sm text-danger"
                        title="Delete"
                        onClick={() => setConfirmId(c.id)}
                      >
                        <i className="bi bi-trash" />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
              {pageItems.length === 0 && (
                <tr>
                  <td colSpan={7}>
                    <div className="empty-state">
                      <i className="bi bi-flower2 mb-2" style={{ fontSize: "1.8rem" }} />
                      <p className="mb-0">No crops match your filters.</p>
                    </div>
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>

        {totalPages > 1 && (
          <div className="d-flex justify-content-between align-items-center p-3 border-top">
            <span className="text-faint" style={{ fontSize: "0.83rem" }}>
              Page {page} of {totalPages}
            </span>
            <div className="d-flex gap-2">
              <button
                className="btn btn-agri-outline btn-sm"
                disabled={page === 1}
                onClick={() => setPage((p) => Math.max(1, p - 1))}
              >
                Previous
              </button>
              <button
                className="btn btn-agri-outline btn-sm"
                disabled={page === totalPages}
                onClick={() => setPage((p) => Math.min(totalPages, p + 1))}
              >
                Next
              </button>
            </div>
          </div>
        )}
      </div>

      {confirmId && (
        <div className="modal d-block" style={{ background: "rgba(20,43,34,0.45)" }} tabIndex="-1">
          <div className="modal-dialog modal-dialog-centered">
            <div className="modal-content" style={{ borderRadius: "var(--radius-md)", border: "none" }}>
              <div className="modal-body p-4">
                <h4>Delete this crop?</h4>
                <p className="mb-4">
                  This will remove the crop record and its monitoring history from this device. This action can't be
                  undone.
                </p>
                <div className="d-flex justify-content-end gap-2">
                  <button className="btn btn-agri-ghost" onClick={() => setConfirmId(null)}>
                    Cancel
                  </button>
                  <button
                    className="btn btn-agri-danger"
                    onClick={() => {
                      deleteCrop(confirmId);
                      setConfirmId(null);
                    }}
                  >
                    Delete Crop
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
