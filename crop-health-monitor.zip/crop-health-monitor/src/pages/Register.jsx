import { useMemo, useState } from "react";
import { Link, Navigate, useNavigate } from "react-router-dom";
import { useAuth } from "../context/AuthContext";
import { cropTypes } from "../data/mockData";

function scorePassword(pw) {
  let score = 0;
  if (pw.length >= 8) score++;
  if (/[A-Z]/.test(pw)) score++;
  if (/[0-9]/.test(pw)) score++;
  if (/[^A-Za-z0-9]/.test(pw)) score++;
  return score;
}

const STRENGTH = [
  { label: "Very weak", color: "#b3432d" },
  { label: "Weak", color: "#c97a2b" },
  { label: "Fair", color: "#d9a441" },
  { label: "Good", color: "#56a67a" },
  { label: "Strong", color: "#2f7a52" },
];

export default function Register() {
  const { user, register } = useAuth();
  const navigate = useNavigate();
  const [form, setForm] = useState({
    fullName: "",
    email: "",
    phone: "",
    password: "",
    confirmPassword: "",
    location: "",
    preferredCrop: cropTypes[0],
  });
  const [errors, setErrors] = useState({});

  if (user) return <Navigate to="/dashboard" replace />;

  const strength = useMemo(() => scorePassword(form.password), [form.password]);

  const handleChange = (e) => setForm({ ...form, [e.target.name]: e.target.value });

  const validate = () => {
    const next = {};
    if (!form.fullName.trim()) next.fullName = "Enter your full name.";
    if (!/^\S+@\S+\.\S+$/.test(form.email)) next.email = "Enter a valid email address.";
    if (!form.phone.trim()) next.phone = "Enter a phone number.";
    if (form.password.length < 6) next.password = "Password must be at least 6 characters.";
    if (form.confirmPassword !== form.password) next.confirmPassword = "Passwords do not match.";
    if (!form.location.trim()) next.location = "Enter your farm location.";
    return next;
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    const next = validate();
    setErrors(next);
    if (Object.keys(next).length) return;
    register(form);
    navigate("/dashboard");
  };

  return (
    <div className="auth-shell">
      <div className="auth-visual">
        <div className="field-rows" />
        <div className="sun-glow" />
        <div className="auth-visual-content">
          <div className="brand mb-5" style={{ color: "#fff" }}>
            <span className="brand-mark">
              <i className="bi bi-flower1" />
            </span>
            AgriSense
          </div>
          <p className="auth-visual-quote">
            Set up your farm profile once. From there, every crop, image, and
            assessment stays organized in a single dashboard.
          </p>
        </div>
        <div className="auth-visual-stats">
          <div className="avs-item">
            <div className="n">7</div>
            <div className="l">Crop types supported</div>
          </div>
          <div className="avs-item">
            <div className="n">Free</div>
            <div className="l">For this demo</div>
          </div>
        </div>
      </div>

      <div className="auth-form-side">
        <div className="auth-card" style={{ maxWidth: 440 }}>
          <h1 className="mb-1">Create your account</h1>
          <p className="mb-4">Set up your farm profile in a minute.</p>

          <form onSubmit={handleSubmit} noValidate>
            <div className="row g-3 mb-3">
              <div className="col-12">
                <label className="form-label">Full name</label>
                <input
                  name="fullName"
                  className={`form-control ${errors.fullName ? "is-invalid" : ""}`}
                  placeholder="Anjali Rao"
                  value={form.fullName}
                  onChange={handleChange}
                />
                {errors.fullName && <div className="invalid-feedback">{errors.fullName}</div>}
              </div>
              <div className="col-md-6">
                <label className="form-label">Email</label>
                <input
                  name="email"
                  type="email"
                  className={`form-control ${errors.email ? "is-invalid" : ""}`}
                  placeholder="you@farmmail.com"
                  value={form.email}
                  onChange={handleChange}
                />
                {errors.email && <div className="invalid-feedback">{errors.email}</div>}
              </div>
              <div className="col-md-6">
                <label className="form-label">Phone number</label>
                <input
                  name="phone"
                  className={`form-control ${errors.phone ? "is-invalid" : ""}`}
                  placeholder="+91 90000 00000"
                  value={form.phone}
                  onChange={handleChange}
                />
                {errors.phone && <div className="invalid-feedback">{errors.phone}</div>}
              </div>

              <div className="col-md-6">
                <label className="form-label">Password</label>
                <input
                  name="password"
                  type="password"
                  className={`form-control ${errors.password ? "is-invalid" : ""}`}
                  placeholder="••••••••"
                  value={form.password}
                  onChange={handleChange}
                />
                {form.password && (
                  <>
                    <div className="pw-strength-bar">
                      <div
                        className="pw-strength-fill"
                        style={{
                          width: `${(strength / 4) * 100}%`,
                          background: STRENGTH[strength].color,
                        }}
                      />
                    </div>
                    <div className="text-faint mt-1" style={{ fontSize: "0.76rem" }}>
                      {STRENGTH[strength].label}
                    </div>
                  </>
                )}
                {errors.password && <div className="invalid-feedback d-block">{errors.password}</div>}
              </div>
              <div className="col-md-6">
                <label className="form-label">Confirm password</label>
                <input
                  name="confirmPassword"
                  type="password"
                  className={`form-control ${errors.confirmPassword ? "is-invalid" : ""}`}
                  placeholder="••••••••"
                  value={form.confirmPassword}
                  onChange={handleChange}
                />
                {errors.confirmPassword && (
                  <div className="invalid-feedback d-block">{errors.confirmPassword}</div>
                )}
              </div>

              <div className="col-md-6">
                <label className="form-label">Farm location</label>
                <input
                  name="location"
                  className={`form-control ${errors.location ? "is-invalid" : ""}`}
                  placeholder="Nalgonda, Telangana"
                  value={form.location}
                  onChange={handleChange}
                />
                {errors.location && <div className="invalid-feedback">{errors.location}</div>}
              </div>
              <div className="col-md-6">
                <label className="form-label">Preferred crop</label>
                <select
                  name="preferredCrop"
                  className="form-select"
                  value={form.preferredCrop}
                  onChange={handleChange}
                >
                  {cropTypes.map((c) => (
                    <option key={c} value={c}>
                      {c}
                    </option>
                  ))}
                </select>
              </div>
            </div>

            <button type="submit" className="btn btn-agri-primary w-100 mb-3 mt-2">
              Create account
            </button>
          </form>

          <hr className="divider" />
          <p className="text-center text-soft mb-0" style={{ fontSize: "0.9rem" }}>
            Already have an account? <Link to="/login">Log in</Link>
          </p>
        </div>
      </div>
    </div>
  );
}
