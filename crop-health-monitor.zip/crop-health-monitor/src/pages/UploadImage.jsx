import { useRef, useState } from "react";
import { useLocation, useNavigate } from "react-router-dom";
import { useData } from "../context/DataContext";
import { useAuth } from "../context/AuthContext";
import StatusPill from "../components/StatusPill";

const MOCK_RESULTS = [
  { healthScore: 82, status: "Needs Attention", possibleIssue: "Possible nutrient deficiency", confidence: 87 },
  { healthScore: 91, status: "Healthy", possibleIssue: "None detected", confidence: 95 },
  { healthScore: 47, status: "Critical", possibleIssue: "Possible fungal disease", confidence: 79 },
  { healthScore: 65, status: "Needs Attention", possibleIssue: "Possible water stress", confidence: 81 },
];

export default function UploadImage() {
  const { crops } = useData();
  const { user } = useAuth();
  const location = useLocation();
  const navigate = useNavigate();
  const fileInputRef = useRef(null);

  const [dragging, setDragging] = useState(false);
  const [preview, setPreview] = useState(null);
  const [fileName, setFileName] = useState("");
  const [cropId, setCropId] = useState(location.state?.cropId || (crops[0] && crops[0].id) || "");
  const [analyzing, setAnalyzing] = useState(false);
  const [result, setResult] = useState(null);

  const handleFiles = (files) => {
    const file = files?.[0];
    if (!file) return;
    if (!/image\/(jpeg|jpg|png)/.test(file.type)) {
      alert("Please upload a JPG, JPEG, or PNG image.");
      return;
    }
    setFileName(file.name);
    setResult(null);
    const reader = new FileReader();
    reader.onload = (e) => setPreview(e.target.result);
    reader.readAsDataURL(file);
  };

  const onDrop = (e) => {
    e.preventDefault();
    setDragging(false);
    handleFiles(e.dataTransfer.files);
  };

  const removeImage = () => {
    setPreview(null);
    setFileName("");
    setResult(null);
  };

  const analyze = () => {
    setAnalyzing(true);
    setTimeout(() => {
      const mock = MOCK_RESULTS[Math.floor(Math.random() * MOCK_RESULTS.length)];
      setResult(mock);
      setAnalyzing(false);
    }, 1400);
  };

  const selectedCrop = crops.find((c) => c.id === cropId);

  const viewFullAssessment = () => {
    navigate("/health-assessment", {
      state: {
        preview,
        result,
        cropId,
        cropName: selectedCrop?.name || "Unassigned crop",
      },
    });
  };

  return (
    <div>
      <div className="mb-4">
        <h1>Upload Crop Image</h1>
        <p className="mb-0">Upload a clear photo of the crop to run a demo health assessment.</p>
      </div>

      <div className="row g-3">
        <div className="col-lg-7">
          <div className="surface-card p-4">
            <label className="form-label">Which crop is this for?</label>
            <select className="form-select mb-4" value={cropId} onChange={(e) => setCropId(e.target.value)}>
              {crops.map((c) => (
                <option key={c.id} value={c.id}>
                  {c.name}
                </option>
              ))}
            </select>

            {!preview ? (
              <div
                className={`dropzone ${dragging ? "dragging" : ""}`}
                onDragOver={(e) => {
                  e.preventDefault();
                  setDragging(true);
                }}
                onDragLeave={() => setDragging(false)}
                onDrop={onDrop}
                onClick={() => fileInputRef.current?.click()}
                role="button"
                tabIndex={0}
              >
                <div className="dropzone-icon">
                  <i className="bi bi-cloud-arrow-up" />
                </div>
                <h4 className="mb-1">Drag and drop your image here</h4>
                <p className="mb-3">or click below to browse your files</p>
                <button
                  type="button"
                  className="btn btn-agri-primary"
                  onClick={(e) => {
                    e.stopPropagation();
                    fileInputRef.current?.click();
                  }}
                >
                  <i className="bi bi-folder2-open me-2" />
                  Browse Image
                </button>
                <p className="text-faint mt-3 mb-0" style={{ fontSize: "0.78rem" }}>
                  Supported formats: JPG, JPEG, PNG
                </p>
                <input
                  ref={fileInputRef}
                  type="file"
                  accept="image/jpeg,image/png,image/jpg"
                  hidden
                  onChange={(e) => handleFiles(e.target.files)}
                />
              </div>
            ) : (
              <div>
                <div className="position-relative">
                  <img
                    src={preview}
                    alt="Preview"
                    className="w-100"
                    style={{ maxHeight: 320, objectFit: "cover", borderRadius: "var(--radius-md)" }}
                  />
                  <button
                    className="btn btn-agri-ghost btn-sm position-absolute top-0 end-0 m-2"
                    style={{ background: "rgba(255,255,255,0.9)" }}
                    onClick={removeImage}
                  >
                    <i className="bi bi-x-lg" />
                  </button>
                </div>
                <div className="d-flex align-items-center justify-content-between mt-3">
                  <span className="text-soft" style={{ fontSize: "0.85rem" }}>
                    <i className="bi bi-file-earmark-image me-1" />
                    {fileName}
                  </span>
                  {!result && (
                    <span className="status-pill status-info">
                      <i className="bi bi-check2" /> Image ready for assessment
                    </span>
                  )}
                </div>

                {!result && (
                  <button
                    className="btn btn-agri-primary w-100 mt-3"
                    onClick={analyze}
                    disabled={analyzing}
                  >
                    {analyzing ? (
                      <>
                        <span className="spinner-border spinner-border-sm me-2" role="status" />
                        Analyzing crop health...
                      </>
                    ) : (
                      <>
                        <i className="bi bi-magic me-2" />
                        Analyze Crop Health
                      </>
                    )}
                  </button>
                )}
              </div>
            )}
          </div>
        </div>

        <div className="col-lg-5">
          <div className="surface-card p-4 h-100">
            <h4 className="mb-1">Demo Assessment Result</h4>
            <p className="mb-3" style={{ fontSize: "0.85rem" }}>
              <i className="bi bi-info-circle me-1" />
              Simulated output — there is no live AI model or backend connected yet.
            </p>

            {!result ? (
              <div className="empty-state">
                <i className="bi bi-clipboard2-pulse mb-2" style={{ fontSize: "1.8rem" }} />
                <p className="mb-0">Upload and analyze an image to see a sample result here.</p>
              </div>
            ) : (
              <div>
                <div className="d-flex align-items-center justify-content-between mb-3">
                  <div>
                    <div className="text-faint" style={{ fontSize: "0.78rem" }}>
                      Crop Health Score
                    </div>
                    <div className="stat-value" style={{ fontSize: "2rem" }}>
                      {result.healthScore}%
                    </div>
                  </div>
                  <StatusPill status={result.status} />
                </div>
                <div className="mb-2">
                  <div className="text-faint" style={{ fontSize: "0.78rem" }}>
                    Possible Issue
                  </div>
                  <div className="fw-semibold">{result.possibleIssue}</div>
                </div>
                <div className="mb-3">
                  <div className="text-faint" style={{ fontSize: "0.78rem" }}>
                    Confidence (estimated)
                  </div>
                  <div className="fw-semibold">{result.confidence}%</div>
                </div>
                <button className="btn btn-agri-primary w-100" onClick={viewFullAssessment}>
                  View Full Assessment <i className="bi bi-arrow-right ms-1" />
                </button>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
