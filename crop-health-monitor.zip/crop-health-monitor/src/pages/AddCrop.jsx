import { useEffect, useState } from "react";
import { useNavigate, useParams } from "react-router-dom";
import { useData } from "../context/DataContext";
import { cropTypes, growthStages, healthConditions } from "../data/mockData";

const emptyForm = {
  name: "",
  type: cropTypes[0],
  location: "",
  plantingDate: "",
  growthStage: growthStages[0],
  area: "",
  status: healthConditions[0],
  notes: "",
};

export default function AddCrop() {
  const { id } = useParams();
  const isEdit = Boolean(id);
  const navigate = useNavigate();
  const { getCropById, addCrop, updateCrop, pushToast } = useData();
  const [form, setForm] = useState(emptyForm);
  const [errors, setErrors] = useState({});

  useEffect(() => {
    if (isEdit) {
      const existing = getCropById(id);
      if (existing) setForm(existing);
    }
  }, [id, isEdit, getCropById]);

  const handleChange = (e) => setForm({ ...form, [e.target.name]: e.target.value });

  const validate = () => {
    const next = {};
    if (!form.name.trim()) next.name = "Give this crop a name.";
    if (!form.location.trim()) next.location = "Enter a field location.";
    if (!form.plantingDate) next.plantingDate = "Select a planting date.";
    if (!form.area.trim()) next.area = "Enter the field size or area.";
    return next;
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    const next = validate();
    setErrors(next);
    if (Object.keys(next).length) return;

    if (isEdit) {
      updateCrop(id, form);
      pushToast(`${form.name} was updated successfully.`);
      navigate(`/crops/${id}`);
    } else {
      const created = addCrop(form);
      navigate(`/crops/${created.id}`);
    }
  };

  return (
    <div>
      <div className="mb-4">
        <h1>{isEdit ? "Edit Crop" : "Add New Crop"}</h1>
        <p className="mb-0">
          {isEdit ? "Update this crop's details." : "Register a new crop or field to start monitoring it."}
        </p>
      </div>

      <form onSubmit={handleSubmit} noValidate>
        <div className="surface-card p-4 mb-3">
          <h4 className="mb-3">Basic details</h4>
          <div className="row g-3">
            <div className="col-md-6">
              <label className="form-label">Crop name</label>
              <input
                name="name"
                className={`form-control ${errors.name ? "is-invalid" : ""}`}
                placeholder="e.g. Tomato Field A"
                value={form.name}
                onChange={handleChange}
              />
              {errors.name && <div className="invalid-feedback">{errors.name}</div>}
            </div>
            <div className="col-md-6">
              <label className="form-label">Crop type</label>
              <select name="type" className="form-select" value={form.type} onChange={handleChange}>
                {cropTypes.map((t) => (
                  <option key={t}>{t}</option>
                ))}
              </select>
            </div>
            <div className="col-md-6">
              <label className="form-label">Location</label>
              <input
                name="location"
                className={`form-control ${errors.location ? "is-invalid" : ""}`}
                placeholder="e.g. North Plot, Sector 4"
                value={form.location}
                onChange={handleChange}
              />
              {errors.location && <div className="invalid-feedback">{errors.location}</div>}
            </div>
            <div className="col-md-6">
              <label className="form-label">Area / field size</label>
              <input
                name="area"
                className={`form-control ${errors.area ? "is-invalid" : ""}`}
                placeholder="e.g. 2.4 acres"
                value={form.area}
                onChange={handleChange}
              />
              {errors.area && <div className="invalid-feedback">{errors.area}</div>}
            </div>
          </div>
        </div>

        <div className="surface-card p-4 mb-3">
          <h4 className="mb-3">Growth &amp; health</h4>
          <div className="row g-3">
            <div className="col-md-4">
              <label className="form-label">Planting date</label>
              <input
                type="date"
                name="plantingDate"
                className={`form-control ${errors.plantingDate ? "is-invalid" : ""}`}
                value={form.plantingDate}
                onChange={handleChange}
              />
              {errors.plantingDate && <div className="invalid-feedback">{errors.plantingDate}</div>}
            </div>
            <div className="col-md-4">
              <label className="form-label">Growth stage</label>
              <select name="growthStage" className="form-select" value={form.growthStage} onChange={handleChange}>
                {growthStages.map((s) => (
                  <option key={s}>{s}</option>
                ))}
              </select>
            </div>
            <div className="col-md-4">
              <label className="form-label">Current health condition</label>
              <select name="status" className="form-select" value={form.status} onChange={handleChange}>
                {healthConditions.map((s) => (
                  <option key={s}>{s}</option>
                ))}
              </select>
            </div>
            <div className="col-12">
              <label className="form-label">Notes</label>
              <textarea
                name="notes"
                className="form-control"
                rows={3}
                placeholder="Anything worth remembering about this crop..."
                value={form.notes}
                onChange={handleChange}
              />
            </div>
          </div>
        </div>

        <div className="d-flex gap-2 justify-content-end">
          <button type="button" className="btn btn-agri-ghost" onClick={() => navigate(-1)}>
            Cancel
          </button>
          <button type="submit" className="btn btn-agri-primary">
            <i className="bi bi-check2 me-2" />
            {isEdit ? "Save Changes" : "Save Crop"}
          </button>
        </div>
      </form>
    </div>
  );
}
