import { useMemo, useState } from "react";
import { Link, useLocation, useNavigate } from "react-router-dom";
import { useData } from "../context/DataContext";
import StatusPill from "../components/StatusPill";

function barColor(v) {
  if (v >= 70) return "var(--green-500)";
  if (v >= 45) return "var(--amber-600)";
  return "var(--red-600)";
}

export default function HealthAssessment() {
  const { assessments, crops, addAssessment, pushToast } = useData();
  const location = useLocation();
  const navigate = useNavigate();
  const incoming = location.state;

  const fallback = assessments[0];
  const [saved, setSaved] = useState(false);

  const view = useMemo(() => {
    if (incoming?.result) {
      const r = incoming.result;
      const b = r.confidence;
      return {
        cropId: incoming.cropId,
        cropName: incoming.cropName,
        image: incoming.preview,
        healthScore: r.healthScore,
        status: r.status,
        possibleIssue: r.possibleIssue,
        confidence: r.confidence,
        breakdown: {
          leaf: Math.max(20, Math.min(99, r.healthScore + 4)),
          color: Math.max(20, Math.min(99, r.healthScore - 6)),
          growth: Math.max(20, Math.min(99, r.healthScore + 2)),
          overall: r.healthScore,
        },
        explanation:
          r.status === "Healthy"
            ? "The uploaded crop image appears consistent with a healthy growth pattern. No corrective action is currently indicated. This is a demo assessment."
            : `The uploaded crop image shows signs that may be consistent with "${r.possibleIssue.toLowerCase()}". This is an estimated, demo assessment — further monitoring is recommended.`,
      };
    }
    if (fallback) {
      const crop = crops.find((c) => c.id === fallback.cropId);
      return { ...fallback, cropName: crop?.name || "Unassigned crop" };
    }
    return null;
  }, [incoming, fallback, crops]);

  if (!view) {
    return (
      <div className="empty-state">
        <i className="bi bi-clipboard2-pulse mb-2" style={{ fontSize: "1.8rem" }} />
        <p>No assessments available yet.</p>
        <Link to="/upload-image" className="btn btn-agri-primary btn-sm">
          Upload a crop image
        </Link>
      </div>
    );
  }

  const handleSave = () => {
    addAssessment({
      cropId: view.cropId,
      cropName: view.cropName,
      healthScore: view.healthScore,
      status: view.status,
      possibleIssue: view.possibleIssue,
      confidence: view.confidence,
      breakdown: view.breakdown,
      explanation: view.explanation,
      image: view.image || "https://images.unsplash.com/photo-1500595046743-cd271d694d30?auto=format&fit=crop&w=400&q=60",
    });
    setSaved(true);
    pushToast("Assessment saved to monitoring history.");
  };

  return (
    <div>
      <div className="mb-4">
        <h1>Health Assessment</h1>
        <p className="mb-0">
          {view.cropName} · {view.date || "Just now"}
        </p>
      </div>

      <div className="row g-3">
        <div className="col-lg-5">
          <div className="surface-card p-3">
            <img
              src={view.image || "https://images.unsplash.com/photo-1500595046743-cd271d694d30?auto=format&fit=crop&w=600&q=60"}
              alt={view.cropName}
              className="w-100"
              style={{ borderRadius: "var(--radius-md)", maxHeight: 320, objectFit: "cover" }}
            />
          </div>
        </div>

        <div className="col-lg-7">
          <div className="surface-card p-4 h-100">
            <div className="d-flex justify-content-between align-items-start mb-3 flex-wrap gap-2">
              <div>
                <div className="text-faint" style={{ fontSize: "0.78rem" }}>
                  Overall Health Score
                </div>
                <div className="stat-value" style={{ fontSize: "2.4rem" }}>
                  {view.healthScore}
                  <span style={{ fontSize: "1rem", color: "var(--ink-faint)" }}>/100</span>
                </div>
              </div>
              <StatusPill status={view.status} />
            </div>

            <div className="row g-3 mb-3">
              <div className="col-6">
                <div className="text-faint" style={{ fontSize: "0.78rem" }}>
                  Possible Issue
                </div>
                <div className="fw-semibold">{view.possibleIssue}</div>
              </div>
              <div className="col-6">
                <div className="text-faint" style={{ fontSize: "0.78rem" }}>
                  Confidence (estimated)
                </div>
                <div className="fw-semibold">{view.confidence}%</div>
              </div>
            </div>

            <hr className="divider" />

            <h4 className="mb-3">Assessment Breakdown</h4>
            {[
              { label: "Leaf Condition", value: view.breakdown.leaf },
              { label: "Color Condition", value: view.breakdown.color },
              { label: "Growth Condition", value: view.breakdown.growth },
              { label: "Overall Condition", value: view.breakdown.overall },
            ].map((row) => (
              <div className="metric-row" key={row.label}>
                <span className="metric-label">{row.label}</span>
                <div className="metric-bar-track">
                  <div
                    className="metric-bar-fill"
                    style={{ width: `${row.value}%`, background: barColor(row.value) }}
                  />
                </div>
                <span className="metric-value">{row.value}%</span>
              </div>
            ))}
          </div>
        </div>
      </div>

      <div className="surface-card p-4 mt-3">
        <h4 className="mb-2">
          <i className="bi bi-file-text me-2" />
          Assessment Explanation
        </h4>
        <p className="mb-3">{view.explanation}</p>
        <div className="alert-item" style={{ borderBottom: "none", background: "var(--blue-100)", borderRadius: "var(--radius-sm)", padding: "0.75rem 1rem" }}>
          <i className="bi bi-info-circle-fill" style={{ color: "var(--blue-600)" }} />
          <p className="mb-0" style={{ fontSize: "0.83rem", color: "var(--forest-950)" }}>
            This is a demo assessment based on simulated data. It does not represent a certified diagnosis — always
            confirm findings with an agricultural expert before taking action.
          </p>
        </div>
      </div>

      <div className="d-flex justify-content-end gap-2 mt-3">
        <Link to="/recommendations" className="btn btn-agri-outline">
          View Recommendations
        </Link>
        <button className="btn btn-agri-primary" onClick={handleSave} disabled={saved || !view.cropId}>
          <i className="bi bi-save me-2" />
          {saved ? "Saved to History" : "Save to Monitoring History"}
        </button>
      </div>
    </div>
  );
}
