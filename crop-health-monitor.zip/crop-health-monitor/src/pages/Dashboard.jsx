import { useMemo } from "react";
import { Link } from "react-router-dom";
import { Doughnut, Line } from "react-chartjs-2";
import { useAuth } from "../context/AuthContext";
import { useData } from "../context/DataContext";
import { healthTrend7d } from "../data/mockData";
import StatCard from "../components/StatCard";
import StatusPill from "../components/StatusPill";
import "../utils/chartSetup";
import { palette, commonScales, tooltipBase } from "../utils/chartSetup";

const SEVERITY_STYLE = {
  critical: { bg: "var(--red-100)", color: "var(--red-600)", icon: "bi-exclamation-triangle-fill" },
  attention: { bg: "var(--amber-100)", color: "var(--amber-600)", icon: "bi-exclamation-circle-fill" },
  info: { bg: "var(--blue-100)", color: "var(--blue-600)", icon: "bi-info-circle-fill" },
};

export default function Dashboard() {
  const { user } = useAuth();
  const { crops, alerts } = useData();

  const stats = useMemo(() => {
    const total = crops.length;
    const healthy = crops.filter((c) => c.status === "Healthy").length;
    const attention = crops.filter((c) => c.status === "Needs Attention").length;
    const critical = crops.filter((c) => c.status === "Critical").length;
    return { total, healthy, attention, critical };
  }, [crops]);

  const today = new Date().toLocaleDateString("en-US", {
    weekday: "long",
    year: "numeric",
    month: "long",
    day: "numeric",
  });

  const doughnutData = {
    labels: ["Healthy", "Needs Attention", "Critical"],
    datasets: [
      {
        data: [stats.healthy, stats.attention, stats.critical],
        backgroundColor: [palette.green, palette.amber, palette.red],
        borderWidth: 0,
        cutout: "72%",
      },
    ],
  };

  const lineData = {
    labels: healthTrend7d.map((d) => d.day),
    datasets: [
      {
        label: "Avg. health score",
        data: healthTrend7d.map((d) => d.score),
        borderColor: palette.green,
        backgroundColor: palette.greenSoft,
        fill: true,
        tension: 0.4,
        pointRadius: 3,
        pointBackgroundColor: palette.green,
      },
    ],
  };

  const recentCrops = [...crops]
    .sort((a, b) => new Date(b.lastChecked) - new Date(a.lastChecked))
    .slice(0, 5);

  return (
    <div>
      <div className="d-flex flex-wrap justify-content-between align-items-start gap-3 mb-4">
        <div>
          <h1 className="mb-1">Good morning, {user?.fullName?.split(" ")[0] || "Farmer"} 👋</h1>
          <p className="mb-1">Here's an overview of your crop health.</p>
          <span className="text-faint" style={{ fontSize: "0.83rem" }}>
            <i className="bi bi-calendar3 me-1" />
            {today}
          </span>
        </div>
        <div className="d-flex gap-2">
          <Link to="/upload-image" className="btn btn-agri-outline">
            <i className="bi bi-camera me-2" />
            Upload Image
          </Link>
          <Link to="/crops/add" className="btn btn-agri-primary">
            <i className="bi bi-plus-lg me-2" />
            Add New Crop
          </Link>
        </div>
      </div>

      <div className="row g-3 mb-4">
        <div className="col-6 col-lg-3">
          <StatCard
            label="Total Crops"
            value={stats.total}
            sub="Across all plots"
            icon="bi-flower2"
            accent="var(--forest-950)"
            accentBg="var(--mint-100)"
          />
        </div>
        <div className="col-6 col-lg-3">
          <StatCard
            label="Healthy"
            value={stats.healthy}
            sub="No action needed"
            icon="bi-check-circle"
            accent="var(--green-600)"
            accentBg="var(--mint-100)"
          />
        </div>
        <div className="col-6 col-lg-3">
          <StatCard
            label="Needs Attention"
            value={stats.attention}
            sub="Recommend a check"
            icon="bi-exclamation-circle"
            accent="var(--amber-600)"
            accentBg="var(--amber-100)"
          />
        </div>
        <div className="col-6 col-lg-3">
          <StatCard
            label="Critical Issues"
            value={stats.critical}
            sub="Needs urgent review"
            icon="bi-exclamation-triangle"
            accent="var(--red-600)"
            accentBg="var(--red-100)"
          />
        </div>
      </div>

      <div className="row g-3 mb-4">
        <div className="col-lg-4">
          <div className="surface-card p-4 h-100">
            <div className="section-heading">
              <h3>Crop Health Overview</h3>
            </div>
            <div style={{ height: 220, position: "relative" }}>
              <Doughnut
                data={doughnutData}
                options={{
                  maintainAspectRatio: false,
                  plugins: {
                    legend: { position: "bottom", labels: { boxWidth: 8, usePointStyle: true, font: { size: 11 } } },
                    tooltip: tooltipBase,
                  },
                }}
              />
            </div>
          </div>
        </div>
        <div className="col-lg-8">
          <div className="surface-card p-4 h-100">
            <div className="section-heading">
              <h3>Crop Health Trend</h3>
              <span className="section-sub">Last 7 days</span>
            </div>
            <div style={{ height: 220 }}>
              <Line
                data={lineData}
                options={{
                  maintainAspectRatio: false,
                  plugins: { legend: { display: false }, tooltip: tooltipBase },
                  scales: { ...commonScales, y: { ...commonScales.y, suggestedMin: 60, suggestedMax: 100 } },
                }}
              />
            </div>
          </div>
        </div>
      </div>

      <div className="row g-3">
        <div className="col-lg-8">
          <div className="surface-card p-4 h-100">
            <div className="section-heading">
              <h3>Recent Crops</h3>
              <Link to="/crops" className="text-soft" style={{ fontSize: "0.85rem" }}>
                View all <i className="bi bi-arrow-right" />
              </Link>
            </div>
            <div className="table-responsive">
              <table className="agri-table">
                <thead>
                  <tr>
                    <th>Crop</th>
                    <th>Type</th>
                    <th>Stage</th>
                    <th>Health Score</th>
                    <th>Status</th>
                    <th>Last Checked</th>
                    <th></th>
                  </tr>
                </thead>
                <tbody>
                  {recentCrops.map((c) => (
                    <tr key={c.id}>
                      <td>
                        <div className="d-flex align-items-center gap-2">
                          <img src={c.image} alt="" className="crop-thumb" />
                          <span className="fw-semibold text-forest">{c.name}</span>
                        </div>
                      </td>
                      <td>{c.type}</td>
                      <td>{c.growthStage}</td>
                      <td className="fw-semibold">{c.healthScore}</td>
                      <td>
                        <StatusPill status={c.status} />
                      </td>
                      <td className="text-faint">{c.lastChecked}</td>
                      <td>
                        <Link to={`/crops/${c.id}`} className="btn btn-agri-ghost btn-sm">
                          View <i className="bi bi-arrow-right" />
                        </Link>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>

        <div className="col-lg-4">
          <div className="surface-card p-4 h-100">
            <div className="section-heading">
              <h3>Recent Alerts</h3>
            </div>
            {alerts.map((a) => {
              const s = SEVERITY_STYLE[a.severity];
              return (
                <div className="alert-item" key={a.id}>
                  <span className="alert-dot" style={{ background: s.bg, color: s.color }}>
                    <i className={`bi ${s.icon}`} />
                  </span>
                  <p className="mb-0" style={{ fontSize: "0.87rem", color: "var(--ink)" }}>
                    {a.text}
                  </p>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </div>
  );
}
