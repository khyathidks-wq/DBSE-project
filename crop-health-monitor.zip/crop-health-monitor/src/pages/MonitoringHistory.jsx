import { useMemo, useState } from "react";
import { Line } from "react-chartjs-2";
import { useData } from "../context/DataContext";
import { healthTrend30d } from "../data/mockData";
import "../utils/chartSetup";
import { palette, commonScales, tooltipBase } from "../utils/chartSetup";

const CONDITION_CLASS = {
  Healthy: "status-healthy",
  "Needs Attention": "status-attention",
  Critical: "status-critical",
};

export default function MonitoringHistory() {
  const { history, crops } = useData();
  const [cropFilter, setCropFilter] = useState("All");
  const [statusFilter, setStatusFilter] = useState("All");
  const [dateFrom, setDateFrom] = useState("");

  const filtered = useMemo(() => {
    return [...history]
      .filter((h) => cropFilter === "All" || h.cropId === cropFilter)
      .filter((h) => statusFilter === "All" || h.condition === statusFilter)
      .filter((h) => !dateFrom || h.date >= dateFrom)
      .sort((a, b) => new Date(b.date) - new Date(a.date));
  }, [history, cropFilter, statusFilter, dateFrom]);

  const lineData = {
    labels: healthTrend30d.map((d) => d.day),
    datasets: [
      {
        label: "Health score",
        data: healthTrend30d.map((d) => d.score),
        borderColor: palette.green,
        backgroundColor: palette.greenSoft,
        fill: true,
        tension: 0.35,
        pointRadius: 0,
      },
    ],
  };

  return (
    <div>
      <div className="mb-4">
        <h1>Monitoring History</h1>
        <p className="mb-0">A full record of every crop health check, over time.</p>
      </div>

      <div className="surface-card p-4 mb-3">
        <div className="section-heading">
          <h3>Health Score Trend</h3>
          <span className="section-sub">Last 30 days</span>
        </div>
        <div style={{ height: 220 }}>
          <Line
            data={lineData}
            options={{
              maintainAspectRatio: false,
              plugins: { legend: { display: false }, tooltip: tooltipBase },
              scales: {
                ...commonScales,
                x: { ...commonScales.x, ticks: { ...commonScales.x.ticks, maxTicksLimit: 8 } },
              },
            }}
          />
        </div>
      </div>

      <div className="surface-card p-3 mb-3">
        <div className="row g-2">
          <div className="col-md-3">
            <select className="form-select" value={cropFilter} onChange={(e) => setCropFilter(e.target.value)}>
              <option value="All">All Crops</option>
              {crops.map((c) => (
                <option key={c.id} value={c.id}>
                  {c.name}
                </option>
              ))}
            </select>
          </div>
          <div className="col-md-3">
            <select className="form-select" value={statusFilter} onChange={(e) => setStatusFilter(e.target.value)}>
              <option value="All">All Statuses</option>
              <option>Healthy</option>
              <option>Needs Attention</option>
              <option>Critical</option>
            </select>
          </div>
          <div className="col-md-3">
            <input
              type="date"
              className="form-control"
              value={dateFrom}
              onChange={(e) => setDateFrom(e.target.value)}
              title="Show entries from this date onward"
            />
          </div>
        </div>
      </div>

      <div className="surface-card p-0">
        <div className="table-responsive">
          <table className="agri-table">
            <thead>
              <tr>
                <th>Date</th>
                <th>Crop</th>
                <th>Health Score</th>
                <th>Condition</th>
                <th>Possible Issue</th>
                <th>Action</th>
              </tr>
            </thead>
            <tbody>
              {filtered.map((h) => (
                <tr key={h.id}>
                  <td className="text-faint">{h.date}</td>
                  <td className="fw-semibold text-forest">{h.cropName}</td>
                  <td className="fw-semibold">{h.healthScore}</td>
                  <td>
                    <span className={`status-pill ${CONDITION_CLASS[h.condition]}`}>{h.condition}</span>
                  </td>
                  <td>{h.issue}</td>
                  <td>{h.action}</td>
                </tr>
              ))}
              {filtered.length === 0 && (
                <tr>
                  <td colSpan={6}>
                    <div className="empty-state">
                      <p className="mb-0">No history entries match your filters.</p>
                    </div>
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
