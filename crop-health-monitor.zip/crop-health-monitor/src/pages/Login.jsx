import { useState } from "react";
import { Link, Navigate, useNavigate } from "react-router-dom";
import { useAuth } from "../context/AuthContext";

export default function Login() {
  const { user, login } = useAuth();
  const navigate = useNavigate();
  const [showPw, setShowPw] = useState(false);
  const [remember, setRemember] = useState(true);
  const [form, setForm] = useState({ email: "", password: "" });
  const [errors, setErrors] = useState({});

  if (user) return <Navigate to="/dashboard" replace />;

  const handleChange = (e) => setForm({ ...form, [e.target.name]: e.target.value });

  const handleSubmit = (e) => {
    e.preventDefault();
    const nextErrors = {};
    if (!form.email) nextErrors.email = "Enter your email to continue.";
    if (!form.password) nextErrors.password = "Enter your password to continue.";
    setErrors(nextErrors);
    if (Object.keys(nextErrors).length) return;
    login(form);
    navigate("/dashboard");
  };

  return (
    <div className="auth-shell">
      <div className="auth-visual">
        <div className="field-rows" />
        <div className="sun-glow" />
        <div className="auth-visual-content">
          <div className="brand mb-5" style={{ color: "#fff" }}>
            <span className="brand-mark">
              <i className="bi bi-flower1" />
            </span>
            AgriSense
          </div>
          <p className="auth-visual-quote">
            Know your fields before the season does. Track growth stages, spot early
            warning signs, and keep every plot on record in one place.
          </p>
        </div>
        <div className="auth-visual-stats">
          <div className="avs-item">
            <div className="n">1,200+</div>
            <div className="l">Crops monitored</div>
          </div>
          <div className="avs-item">
            <div className="n">94%</div>
            <div className="l">Issues caught early</div>
          </div>
          <div className="avs-item">
            <div className="n">30 sec</div>
            <div className="l">Per assessment</div>
          </div>
        </div>
      </div>

      <div className="auth-form-side">
        <div className="auth-card">
          <h1 className="mb-1">Welcome back</h1>
          <p className="mb-4">Log in to check on your fields.</p>

          <form onSubmit={handleSubmit} noValidate>
            <div className="mb-3">
              <label className="form-label">Email address</label>
              <input
                type="email"
                name="email"
                className={`form-control ${errors.email ? "is-invalid" : ""}`}
                placeholder="you@farmmail.com"
                value={form.email}
                onChange={handleChange}
              />
              {errors.email && <div className="invalid-feedback">{errors.email}</div>}
            </div>

            <div className="mb-2">
              <label className="form-label">Password</label>
              <div className="input-affix">
                <input
                  type={showPw ? "text" : "password"}
                  name="password"
                  className={`form-control ${errors.password ? "is-invalid" : ""}`}
                  placeholder="••••••••"
                  value={form.password}
                  onChange={handleChange}
                />
                <button
                  type="button"
                  className="affix-btn"
                  onClick={() => setShowPw((v) => !v)}
                  aria-label={showPw ? "Hide password" : "Show password"}
                >
                  <i className={`bi ${showPw ? "bi-eye-slash" : "bi-eye"}`} />
                </button>
              </div>
              {errors.password && <div className="invalid-feedback d-block">{errors.password}</div>}
            </div>

            <div className="d-flex justify-content-between align-items-center mb-4 mt-3">
              <div className="form-check">
                <input
                  className="form-check-input"
                  type="checkbox"
                  id="remember"
                  checked={remember}
                  onChange={() => setRemember((v) => !v)}
                />
                <label className="form-check-label text-soft" htmlFor="remember" style={{ fontSize: "0.87rem" }}>
                  Remember me
                </label>
              </div>
              <a href="#!" className="text-soft" style={{ fontSize: "0.87rem" }}>
                Forgot password?
              </a>
            </div>

            <button type="submit" className="btn btn-agri-primary w-100 mb-3">
              Log in
            </button>
            <p className="text-center text-faint mb-0" style={{ fontSize: "0.85rem" }}>
              This is a demo login — any email and password will work.
            </p>
          </form>

          <hr className="divider" />
          <p className="text-center text-soft mb-0" style={{ fontSize: "0.9rem" }}>
            New to AgriSense? <Link to="/register">Create an account</Link>
          </p>
        </div>
      </div>
    </div>
  );
}
