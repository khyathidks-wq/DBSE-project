import { Bar, Doughnut, Line } from "react-chartjs-2";
import { useData } from "../context/DataContext";
import {
  healthTrend30d,
  cropDistribution,
  monitoringActivity,
  insights,
} from "../data/mockData";
import "../utils/chartSetup";
import { palette, commonScales, tooltipBase } from "../utils/chartSetup";

const DIST_COLORS = [palette.green, palette.blue, palette.amber, palette.red, palette.mint, "#7a9e6b", "#4f7a8f"];

export default function Analytics() {
  const { crops } = useData();

  const statusCounts = {
    Healthy: crops.filter((c) => c.status === "Healthy").length,
    "Needs Attention": crops.filter((c) => c.status === "Needs Attention").length,
    Critical: crops.filter((c) => c.status === "Critical").length,
  };

  const trendData = {
    labels: healthTrend30d.map((d) => d.day),
    datasets: [
      {
        label: "Health score",
        data: healthTrend30d.map((d) => d.score),
        borderColor: palette.green,
        backgroundColor: palette.greenSoft,
        fill: true,
        tension: 0.35,
        pointRadius: 0,
      },
    ],
  };

  const distributionData = {
    labels: cropDistribution.map((d) => d.type),
    datasets: [
      {
        data: cropDistribution.map((d) => d.count),
        backgroundColor: DIST_COLORS,
        borderWidth: 0,
        cutout: "68%",
      },
    ],
  };

  const statusData = {
    labels: Object.keys(statusCounts),
    datasets: [
      {
        data: Object.values(statusCounts),
        backgroundColor: [palette.green, palette.amber, palette.red],
        borderRadius: 6,
        maxBarThickness: 46,
      },
    ],
  };

  const activityData = {
    labels: monitoringActivity.map((d) => d.week),
    datasets: [
      {
        label: "Checks performed",
        data: monitoringActivity.map((d) => d.checks),
        backgroundColor: palette.blue,
        borderRadius: 6,
        maxBarThickness: 46,
      },
    ],
  };

  return (
    <div>
      <div className="mb-4">
        <h1>Analytics</h1>
        <p className="mb-0">A closer look at crop health trends across your farm.</p>
      </div>

      <div className="row g-3 mb-3">
        <div className="col-lg-8">
          <div className="surface-card p-4 h-100">
            <div className="section-heading">
              <h3>Health Score Trend</h3>
              <span className="section-sub">Last 30 days</span>
            </div>
            <div style={{ height: 240 }}>
              <Line
                data={trendData}
                options={{
                  maintainAspectRatio: false,
                  plugins: { legend: { display: false }, tooltip: tooltipBase },
                  scales: {
                    ...commonScales,
                    x: { ...commonScales.x, ticks: { ...commonScales.x.ticks, maxTicksLimit: 8 } },
                  },
                }}
              />
            </div>
          </div>
        </div>
        <div className="col-lg-4">
          <div className="surface-card p-4 h-100">
            <div className="section-heading">
              <h3>Crop Distribution</h3>
            </div>
            <div style={{ height: 240, position: "relative" }}>
              <Doughnut
                data={distributionData}
                options={{
                  maintainAspectRatio: false,
                  plugins: {
                    legend: { position: "bottom", labels: { boxWidth: 8, usePointStyle: true, font: { size: 10 } } },
                    tooltip: tooltipBase,
                  },
                }}
              />
            </div>
          </div>
        </div>
      </div>

      <div className="row g-3 mb-3">
        <div className="col-lg-6">
          <div className="surface-card p-4 h-100">
            <div className="section-heading">
              <h3>Health Status Breakdown</h3>
            </div>
            <div style={{ height: 220 }}>
              <Bar
                data={statusData}
                options={{
                  maintainAspectRatio: false,
                  plugins: { legend: { display: false }, tooltip: tooltipBase },
                  scales: commonScales,
                }}
              />
            </div>
          </div>
        </div>
        <div className="col-lg-6">
          <div className="surface-card p-4 h-100">
            <div className="section-heading">
              <h3>Monitoring Activity</h3>
              <span className="section-sub">Checks per week</span>
            </div>
            <div style={{ height: 220 }}>
              <Bar
                data={activityData}
                options={{
                  maintainAspectRatio: false,
                  plugins: { legend: { display: false }, tooltip: tooltipBase },
                  scales: commonScales,
                }}
              />
            </div>
          </div>
        </div>
      </div>

      <div className="surface-card p-4">
        <div className="section-heading">
          <h3>Key Insights</h3>
        </div>
        <div className="row g-3">
          {insights.map((text, i) => (
            <div className="col-md-6" key={i}>
              <div className="d-flex gap-2 align-items-start">
                <span
                  className="stat-icon-badge"
                  style={{ width: 32, height: 32, fontSize: "0.9rem", "--accent": "var(--green-600)", "--accent-bg": "var(--mint-100)" }}
                >
                  <i className="bi bi-lightbulb" />
                </span>
                <p className="mb-0" style={{ fontSize: "0.9rem" }}>
                  {text}
                </p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
