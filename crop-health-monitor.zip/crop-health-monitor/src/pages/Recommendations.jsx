import { useMemo, useState } from "react";
import { recommendations } from "../data/mockData";

const PRIORITY_META = {
  High: { cls: "status-critical", icon: "bi-exclamation-triangle-fill" },
  Medium: { cls: "status-attention", icon: "bi-exclamation-circle-fill" },
  Low: { cls: "status-healthy", icon: "bi-check-circle-fill" },
};

const FILTERS = ["All", "High Priority", "Medium Priority", "Low Priority"];

export default function Recommendations() {
  const [filter, setFilter] = useState("All");

  const filtered = useMemo(() => {
    if (filter === "All") return recommendations;
    const priority = filter.split(" ")[0];
    return recommendations.filter((r) => r.priority === priority);
  }, [filter]);

  return (
    <div>
      <div className="mb-4">
        <h1>Recommendations</h1>
        <p className="mb-0">Suggested actions based on the latest crop health assessments.</p>
      </div>

      <div className="d-flex gap-2 mb-4 flex-wrap">
        {FILTERS.map((f) => (
          <button key={f} className={`chip ${filter === f ? "active" : ""}`} onClick={() => setFilter(f)}>
            {f}
          </button>
        ))}
      </div>

      <div className="row g-3">
        {filtered.map((r) => {
          const meta = PRIORITY_META[r.priority];
          return (
            <div className="col-md-6" key={r.id}>
              <div className="surface-card p-4 h-100">
                <div className="d-flex justify-content-between align-items-start mb-2">
                  <h4 className="mb-0">{r.issue}</h4>
                  <span className={`status-pill ${meta.cls}`}>
                    <i className={`bi ${meta.icon}`} /> {r.priority} Priority
                  </span>
                </div>
                <p className="text-faint mb-3" style={{ fontSize: "0.8rem" }}>
                  <i className="bi bi-flower2 me-1" />
                  {r.crop}
                </p>
                <p className="mb-3">{r.action}</p>
                <div className="d-flex align-items-center gap-2 text-soft" style={{ fontSize: "0.83rem" }}>
                  <i className="bi bi-calendar-check" />
                  {r.monitoring}
                </div>
              </div>
            </div>
          );
        })}
        {filtered.length === 0 && (
          <div className="empty-state">
            <p className="mb-0">No recommendations match this filter.</p>
          </div>
        )}
      </div>
    </div>
  );
}
