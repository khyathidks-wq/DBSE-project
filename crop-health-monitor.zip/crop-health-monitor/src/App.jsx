import { BrowserRouter, Routes, Route, Navigate } from "react-router-dom";
import { AuthProvider } from "./context/AuthContext";
import { DataProvider } from "./context/DataContext";
import AppLayout from "./components/AppLayout";

import Login from "./pages/Login";
import Register from "./pages/Register";
import Dashboard from "./pages/Dashboard";
import CropManagement from "./pages/CropManagement";
import AddCrop from "./pages/AddCrop";
import CropDetails from "./pages/CropDetails";
import UploadImage from "./pages/UploadImage";
import HealthAssessment from "./pages/HealthAssessment";
import Recommendations from "./pages/Recommendations";
import MonitoringHistory from "./pages/MonitoringHistory";
import Analytics from "./pages/Analytics";
import Profile from "./pages/Profile";
import NotFound from "./pages/NotFound";

export default function App() {
  return (
    <BrowserRouter>
      <AuthProvider>
        <DataProvider>
          <Routes>
            <Route path="/" element={<Navigate to="/dashboard" replace />} />
            <Route path="/login" element={<Login />} />
            <Route path="/register" element={<Register />} />

            <Route element={<AppLayout />}>
              <Route path="/dashboard" element={<Dashboard />} />
              <Route path="/crops" element={<CropManagement />} />
              <Route path="/crops/add" element={<AddCrop />} />
              <Route path="/crops/:id" element={<CropDetails />} />
              <Route path="/crops/:id/edit" element={<AddCrop />} />
              <Route path="/upload-image" element={<UploadImage />} />
              <Route path="/health-assessment" element={<HealthAssessment />} />
              <Route path="/recommendations" element={<Recommendations />} />
              <Route path="/history" element={<MonitoringHistory />} />
              <Route path="/analytics" element={<Analytics />} />
              <Route path="/profile" element={<Profile />} />
            </Route>

            <Route path="*" element={<NotFound />} />
          </Routes>
        </DataProvider>
      </AuthProvider>
    </BrowserRouter>
  );
}
