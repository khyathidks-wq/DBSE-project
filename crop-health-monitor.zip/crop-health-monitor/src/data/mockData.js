// Realistic mock/sample data — structured so it can be swapped for real
// REST API responses (see src/utils/api.js) without changing component code.

export const growthStages = ["Seedling", "Vegetative", "Flowering", "Fruiting", "Harvest"];
export const healthConditions = ["Healthy", "Needs Attention", "Critical"];
export const cropTypes = ["Tomato", "Rice", "Cotton", "Chili", "Maize", "Wheat", "Sugarcane"];

const img = (seed) => `https://images.unsplash.com/${seed}?auto=format&fit=crop&w=400&q=60`;

export const initialCrops = [
  {
    id: "c1",
    name: "Tomato Field A",
    type: "Tomato",
    location: "North Plot, Sector 4",
    plantingDate: "2026-06-12",
    growthStage: "Fruiting",
    area: "2.4 acres",
    healthScore: 85,
    status: "Healthy",
    lastChecked: "2026-09-15",
    image: img("photo-1592841200221-a6898f307baa"),
    notes: "Drip irrigation installed this season.",
  },
  {
    id: "c2",
    name: "Rice Field 1",
    type: "Rice",
    location: "Riverside Plot",
    plantingDate: "2026-05-28",
    growthStage: "Vegetative",
    area: "5 acres",
    healthScore: 58,
    status: "Needs Attention",
    lastChecked: "2026-09-14",
    image: img("photo-1568347355280-d33fdf76c40d"),
    notes: "Standing water level slightly low.",
  },
  {
    id: "c3",
    name: "Cotton Field",
    type: "Cotton",
    location: "West Boundary Plot",
    plantingDate: "2026-06-02",
    growthStage: "Flowering",
    area: "3.1 acres",
    healthScore: 41,
    status: "Critical",
    lastChecked: "2026-09-13",
    image: img("photo-1595855709190-79f2b7d3aa4d"),
    notes: "Leaf curling observed on the eastern rows.",
  },
  {
    id: "c4",
    name: "Chili Field",
    type: "Chili",
    location: "South Terrace",
    plantingDate: "2026-07-01",
    growthStage: "Flowering",
    area: "1.2 acres",
    healthScore: 79,
    status: "Healthy",
    lastChecked: "2026-09-15",
    image: img("photo-1583119022894-919a68a3d0e3"),
    notes: "",
  },
  {
    id: "c5",
    name: "Maize Field",
    type: "Maize",
    location: "East Plot 2",
    plantingDate: "2026-06-18",
    growthStage: "Vegetative",
    area: "4 acres",
    healthScore: 72,
    status: "Needs Attention",
    lastChecked: "2026-09-11",
    image: img("photo-1601472764882-52a018c99b28"),
    notes: "Possible nutrient deficiency flagged last check.",
  },
  {
    id: "c6",
    name: "Wheat Field B",
    type: "Wheat",
    location: "North Plot, Sector 2",
    plantingDate: "2026-05-05",
    growthStage: "Harvest",
    area: "6.2 acres",
    healthScore: 91,
    status: "Healthy",
    lastChecked: "2026-09-12",
    image: img("photo-1500595046743-cd271d694d30"),
    notes: "",
  },
];

export const initialAssessments = [
  {
    id: "a1",
    cropId: "c2",
    date: "2026-09-14",
    healthScore: 58,
    status: "Needs Attention",
    possibleIssue: "Possible nutrient deficiency",
    confidence: 84,
    breakdown: { leaf: 62, color: 55, growth: 70, overall: 58 },
    explanation:
      "The uploaded crop image indicates signs that may be consistent with a possible nutrient-related issue. Leaf yellowing along the margins was noted. Further monitoring is recommended.",
    image: img("photo-1568347355280-d33fdf76c40d"),
  },
  {
    id: "a2",
    cropId: "c3",
    date: "2026-09-13",
    healthScore: 41,
    status: "Critical",
    possibleIssue: "Possible fungal disease",
    confidence: 79,
    breakdown: { leaf: 38, color: 40, growth: 45, overall: 41 },
    explanation:
      "Leaf curling and dark spotting patterns were detected that may be consistent with a fungal issue. This is an estimated, demo assessment — please confirm with an agricultural expert before taking action.",
    image: img("photo-1595855709190-79f2b7d3aa4d"),
  },
  {
    id: "a3",
    cropId: "c5",
    date: "2026-09-11",
    healthScore: 72,
    status: "Needs Attention",
    possibleIssue: "Possible nutrient deficiency",
    confidence: 87,
    breakdown: { leaf: 74, color: 68, growth: 76, overall: 72 },
    explanation:
      "Slight discoloration was observed across the sampled leaves, consistent with a possible early-stage nutrient deficiency. Continued monitoring over the next few checks is recommended.",
    image: img("photo-1601472764882-52a018c99b28"),
  },
  {
    id: "a4",
    cropId: "c1",
    date: "2026-09-15",
    healthScore: 85,
    status: "Healthy",
    possibleIssue: "None detected",
    confidence: 92,
    breakdown: { leaf: 88, color: 84, growth: 86, overall: 85 },
    explanation:
      "The sampled leaves and fruiting structures appear consistent with a healthy growth pattern. No corrective action is currently indicated.",
    image: img("photo-1592841200221-a6898f307baa"),
  },
];

export const initialHistory = [
  { id: "h1", date: "2026-09-15", cropId: "c1", cropName: "Tomato Field A", healthScore: 85, condition: "Healthy", issue: "None", action: "Continue Monitoring" },
  { id: "h2", date: "2026-09-10", cropId: "c1", cropName: "Tomato Field A", healthScore: 78, condition: "Needs Attention", issue: "Possible Nutrient Deficiency", action: "Review Nutrients" },
  { id: "h3", date: "2026-09-05", cropId: "c1", cropName: "Tomato Field A", healthScore: 72, condition: "Needs Attention", issue: "Possible Issue", action: "Monitor" },
  { id: "h4", date: "2026-09-14", cropId: "c2", cropName: "Rice Field 1", healthScore: 58, condition: "Needs Attention", issue: "Possible Nutrient Deficiency", action: "Review Nutrients" },
  { id: "h5", date: "2026-09-08", cropId: "c2", cropName: "Rice Field 1", healthScore: 64, condition: "Needs Attention", issue: "Possible Water Stress", action: "Adjust Irrigation" },
  { id: "h6", date: "2026-09-13", cropId: "c3", cropName: "Cotton Field", healthScore: 41, condition: "Critical", issue: "Possible Fungal Disease", action: "Isolate & Inspect" },
  { id: "h7", date: "2026-09-06", cropId: "c3", cropName: "Cotton Field", healthScore: 53, condition: "Needs Attention", issue: "Possible Pest Activity", action: "Monitor Closely" },
  { id: "h8", date: "2026-09-15", cropId: "c4", cropName: "Chili Field", healthScore: 79, condition: "Healthy", issue: "None", action: "Continue Monitoring" },
  { id: "h9", date: "2026-09-11", cropId: "c5", cropName: "Maize Field", healthScore: 72, condition: "Needs Attention", issue: "Possible Nutrient Deficiency", action: "Review Nutrients" },
  { id: "h10", date: "2026-09-12", cropId: "c6", cropName: "Wheat Field B", healthScore: 91, condition: "Healthy", issue: "None", action: "Continue Monitoring" },
];

export const healthTrend7d = [
  { day: "Sep 9", score: 78 },
  { day: "Sep 10", score: 80 },
  { day: "Sep 11", score: 76 },
  { day: "Sep 12", score: 82 },
  { day: "Sep 13", score: 85 },
  { day: "Sep 14", score: 84 },
  { day: "Sep 15", score: 88 },
];

export const healthTrend30d = Array.from({ length: 30 }).map((_, i) => {
  const base = 70 + Math.round(12 * Math.sin(i / 4)) + (i > 22 ? 6 : 0);
  const d = new Date(2026, 7, 17 + i);
  return { day: d.toLocaleDateString("en-US", { month: "short", day: "numeric" }), score: Math.max(40, Math.min(96, base)) };
});

export const monitoringActivity = [
  { week: "Wk 1", checks: 9 },
  { week: "Wk 2", checks: 14 },
  { week: "Wk 3", checks: 11 },
  { week: "Wk 4", checks: 17 },
];

export const recommendations = [
  {
    id: "r1",
    issue: "Healthy",
    priority: "Low",
    action: "Continue regular monitoring and maintain current care practices.",
    monitoring: "Re-check in 7 days.",
    crop: "Tomato Field A",
  },
  {
    id: "r2",
    issue: "Possible Nutrient Deficiency",
    priority: "Medium",
    action:
      "Review crop nutrient management and monitor plant growth. Consider appropriate corrective measures based on local agricultural guidance.",
    monitoring: "Re-check in 3–5 days.",
    crop: "Rice Field 1",
  },
  {
    id: "r3",
    issue: "Possible Fungal Disease",
    priority: "High",
    action: "Monitor affected plants closely and consider appropriate preventive or corrective measures.",
    monitoring: "Re-check in 1–2 days.",
    crop: "Cotton Field",
  },
  {
    id: "r4",
    issue: "Possible Nutrient Deficiency",
    priority: "Medium",
    action:
      "Review crop nutrient management and monitor plant growth. Consider appropriate corrective measures based on local agricultural guidance.",
    monitoring: "Re-check in 3–5 days.",
    crop: "Maize Field",
  },
  {
    id: "r5",
    issue: "Possible Water Stress",
    priority: "Medium",
    action: "Assess irrigation schedule and soil moisture levels; adjust watering frequency if needed.",
    monitoring: "Re-check in 2–3 days.",
    crop: "Rice Field 1",
  },
  {
    id: "r6",
    issue: "Healthy",
    priority: "Low",
    action: "No corrective action indicated. Maintain current monitoring routine.",
    monitoring: "Re-check in 7 days.",
    crop: "Wheat Field B",
  },
];

export const alerts = [
  { id: "al1", severity: "critical", text: "Cotton Field may require urgent attention — possible fungal disease detected." },
  { id: "al2", severity: "attention", text: "Rice Field 1: possible nutrient deficiency detected." },
  { id: "al3", severity: "info", text: "Maize Field monitoring is due for a re-check." },
  { id: "al4", severity: "attention", text: "Tomato Field A may require attention within the next few days." },
];

export const cropDistribution = cropTypes
  .map((t) => ({ type: t, count: initialCrops.filter((c) => c.type === t).length }))
  .filter((d) => d.count > 0);

export const insights = [
  "Most monitored crops are currently healthy.",
  "Tomato Field A showed a steady improvement over the last 7 days.",
  "3 crops currently require additional attention.",
  "Cotton Field has the lowest health score this week and should be prioritized.",
  "Monitoring activity increased 21% compared to last month.",
];
