import { useData } from "../context/DataContext";

const ICONS = {
  success: "bi-check-circle-fill",
  danger: "bi-exclamation-circle-fill",
  info: "bi-info-circle-fill",
};

export default function ToastStack() {
  const { toasts } = useData();
  if (!toasts.length) return null;
  return (
    <div className="agri-toast-wrap">
      {toasts.map((t) => (
        <div className="agri-toast" key={t.id}>
          <i className={`bi ${ICONS[t.variant] || ICONS.success}`} style={{ color: t.variant === "danger" ? "#e08a75" : "#8fd6ab" }} />
          <span>{t.message}</span>
        </div>
      ))}
    </div>
  );
}
