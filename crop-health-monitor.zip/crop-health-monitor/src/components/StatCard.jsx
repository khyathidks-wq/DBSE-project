export default function StatCard({ label, value, sub, icon, accent, accentBg }) {
  return (
    <div className="stat-card" style={{ "--accent": accent, "--accent-bg": accentBg }}>
      <div>
        <div className="stat-label">{label}</div>
        <div className="stat-value">{value}</div>
        {sub && <div className="stat-sub">{sub}</div>}
      </div>
      <div className="stat-icon-badge">
        <i className={`bi ${icon}`} />
      </div>
    </div>
  );
}
