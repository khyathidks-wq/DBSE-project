const MAP = {
  Healthy: "status-healthy",
  "Needs Attention": "status-attention",
  Critical: "status-critical",
};

export default function StatusPill({ status }) {
  return <span className={`status-pill ${MAP[status] || "status-info"}`}>{status}</span>;
}
