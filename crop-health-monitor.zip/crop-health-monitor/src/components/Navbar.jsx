import { useState } from "react";
import { NavLink, useNavigate } from "react-router-dom";
import { useAuth } from "../context/AuthContext";

const NAV_ITEMS = [
  { to: "/dashboard", label: "Dashboard", icon: "bi-grid-1x2" },
  { to: "/crops", label: "Crops", icon: "bi-flower2" },
  { to: "/health-assessment", label: "Health Assessment", icon: "bi-clipboard2-pulse" },
  { to: "/history", label: "History", icon: "bi-clock-history" },
  { to: "/analytics", label: "Analytics", icon: "bi-bar-chart-line" },
  { to: "/recommendations", label: "Recommendations", icon: "bi-lightbulb" },
  { to: "/profile", label: "Profile", icon: "bi-person-circle" },
];

export default function Navbar() {
  const { user, logout } = useAuth();
  const navigate = useNavigate();
  const [drawerOpen, setDrawerOpen] = useState(false);

  const initials = (user?.fullName || "F")
    .split(" ")
    .map((p) => p[0])
    .slice(0, 2)
    .join("")
    .toUpperCase();

  const handleLogout = () => {
    logout();
    navigate("/login");
  };

  return (
    <header className="topnav">
      <div className="topnav-inner">
        <button className="mobile-nav-toggle" onClick={() => setDrawerOpen((v) => !v)} aria-label="Toggle menu">
          <i className="bi bi-list" />
        </button>
        <NavLink to="/dashboard" className="brand">
          <span className="brand-mark">
            <i className="bi bi-flower1" />
          </span>
          AgriSense
        </NavLink>
        <nav className="nav-links">
          {NAV_ITEMS.map((item) => (
            <NavLink
              key={item.to}
              to={item.to}
              className={({ isActive }) => "nav-link-item" + (isActive ? " active" : "")}
            >
              <i className={`bi ${item.icon}`} />
              {item.label}
            </NavLink>
          ))}
        </nav>
        <div className="nav-right">
          <button className="nav-icon-btn" aria-label="Notifications">
            <i className="bi bi-bell" />
            <span className="notif-dot" />
          </button>
          <div className="dropdown">
            <button
              className="user-chip"
              data-bs-toggle="dropdown"
              aria-expanded="false"
            >
              <span className="avatar-circle">{initials}</span>
              <span className="d-none d-md-inline" style={{ fontSize: "0.85rem", fontWeight: 600 }}>
                {user?.fullName}
              </span>
              <i className="bi bi-chevron-down" style={{ fontSize: "0.7rem" }} />
            </button>
            <ul className="dropdown-menu dropdown-menu-end mt-2">
              <li>
                <NavLink className="dropdown-item" to="/profile">
                  <i className="bi bi-person me-2" />
                  Profile &amp; Settings
                </NavLink>
              </li>
              <li>
                <hr className="dropdown-divider" />
              </li>
              <li>
                <button className="dropdown-item text-danger" onClick={handleLogout}>
                  <i className="bi bi-box-arrow-right me-2" />
                  Log out
                </button>
              </li>
            </ul>
          </div>
        </div>
      </div>
      {drawerOpen && (
        <div className="mobile-drawer">
          <nav className="d-flex flex-column gap-1">
            {NAV_ITEMS.map((item) => (
              <NavLink
                key={item.to}
                to={item.to}
                onClick={() => setDrawerOpen(false)}
                className={({ isActive }) => "nav-link-item" + (isActive ? " active" : "")}
              >
                <i className={`bi ${item.icon}`} />
                {item.label}
              </NavLink>
            ))}
            <button className="nav-link-item text-start" onClick={handleLogout}>
              <i className="bi bi-box-arrow-right" />
              Log out
            </button>
          </nav>
        </div>
      )}
    </header>
  );
}
