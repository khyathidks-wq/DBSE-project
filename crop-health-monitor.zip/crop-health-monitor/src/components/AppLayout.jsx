import { Navigate, Outlet } from "react-router-dom";
import Navbar from "./Navbar";
import ToastStack from "./ToastStack";
import { useAuth } from "../context/AuthContext";

export default function AppLayout() {
  const { user, ready } = useAuth();

  if (!ready) return null;
  if (!user) return <Navigate to="/login" replace />;

  return (
    <div className="app-shell">
      <Navbar />
      <main className="page-wrap">
        <Outlet />
      </main>
      <ToastStack />
    </div>
  );
}
