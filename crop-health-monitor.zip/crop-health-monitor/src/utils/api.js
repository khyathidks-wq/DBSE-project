import axios from "axios";

// Pre-configured Axios instance. Once the Node.js/Express backend exists,
// point VITE_API_BASE_URL at it (e.g. http://localhost:5000/api) and the
// rest of the app can swap mock-data calls for real requests with no
// structural changes — every page already models its data the same way
// the endpoints below are expected to return it.
const api = axios.create({
  baseURL: import.meta.env.VITE_API_BASE_URL || "/api",
  headers: { "Content-Type": "application/json" },
});

api.interceptors.request.use((config) => {
  const token = localStorage.getItem("agrisense_token");
  if (token) config.headers.Authorization = `Bearer ${token}`;
  return config;
});

// Reference shape of the endpoints this frontend expects:
//   POST   /auth/login            { email, password }
//   POST   /auth/register         { fullName, email, phone, password, location, preferredCrop }
//   GET    /crops                 -> Crop[]
//   POST   /crops                 -> Crop
//   GET    /crops/:id             -> Crop
//   PUT    /crops/:id             -> Crop
//   DELETE /crops/:id
//   POST   /crops/:id/assessments -> Assessment   (multipart image upload)
//   GET    /crops/:id/history     -> HistoryEntry[]
//   GET    /analytics/overview    -> { trend, distribution, statusCounts, insights }

export default api;
