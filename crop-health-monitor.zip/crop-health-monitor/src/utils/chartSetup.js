import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  BarElement,
  ArcElement,
  Tooltip,
  Legend,
  Filler,
} from "chart.js";

ChartJS.register(
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  BarElement,
  ArcElement,
  Tooltip,
  Legend,
  Filler
);

export const palette = {
  green: "#2f7a52",
  greenSoft: "rgba(47, 122, 82, 0.14)",
  mint: "#8fbf9f",
  amber: "#c97a2b",
  red: "#b3432d",
  blue: "#3b6e8f",
  ink: "#5b6b62",
  grid: "#e9f0e9",
};

export const baseFont = {
  family: "Inter, sans-serif",
  size: 11,
};

export const commonScales = {
  x: {
    grid: { display: false },
    ticks: { color: palette.ink, font: baseFont },
    border: { color: palette.grid },
  },
  y: {
    grid: { color: palette.grid },
    ticks: { color: palette.ink, font: baseFont },
    border: { display: false },
  },
};

export const tooltipBase = {
  backgroundColor: "#142b22",
  titleFont: { family: "Inter, sans-serif", weight: "600" },
  bodyFont: { family: "Inter, sans-serif" },
  padding: 10,
  cornerRadius: 8,
  displayColors: false,
};
