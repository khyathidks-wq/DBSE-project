# AgriSense — Crop Health Monitoring System (Frontend)

A frontend-only React application for a smart agricultural crop health
monitoring platform, built for a college project. It runs entirely on mock
data — no backend is required to explore every screen.

## Tech stack

- React 19 + Vite
- React Router v7 for client-side routing
- Bootstrap 5 for layout/components, plus a custom design system (`src/index.css`)
- Bootstrap Icons
- Chart.js + react-chartjs-2 for the dashboard/analytics charts
- Axios, pre-wired in `src/utils/api.js` for when a real backend is added

## Getting started

```bash
npm install
npm run dev       # start the dev server (usually http://localhost:5173)
npm run build     # production build, output in dist/
npm run preview   # preview the production build locally
```

## Demo accounts

Authentication is mocked. On the **Login** page, any email/password
combination will work — it creates a session in `localStorage` and takes you
straight to the dashboard. **Register** works the same way.

## Project structure

```
src/
  components/     Navbar, layout shell, shared stat cards, status pills, toasts
  context/        AuthContext (mock auth) and DataContext (crops/assessments/history)
  data/           mockData.js — every sample record used across the app
  pages/          one file per route (Login, Dashboard, Crop Management, ...)
  utils/          api.js (Axios instance + expected endpoint shapes),
                  chartSetup.js (Chart.js registration + shared styling)
```

## Connecting a real backend later

`src/utils/api.js` documents the REST endpoints this frontend expects
(`/auth/login`, `/crops`, `/crops/:id/assessments`, etc). Once the
Node.js/Express + MySQL backend exists, set `VITE_API_BASE_URL` in a `.env`
file and swap the mock calls in `DataContext.jsx` / `AuthContext.jsx` for
`api.get/post/...` calls — the rest of the UI already expects data in this
shape, so no component changes should be needed.

## Notes on the "AI" health assessment

The crop image analysis on the Upload Image / Health Assessment pages is a
**simulated demo** — it picks from a set of mock results rather than running
a real model. This is called out directly in the UI so it's clear during a
project review.
